<?php

	$cd_host = "127.0.0.1";
	$cd_port = 3306;
	$cd_socket = "";
	$cd_user = "root"; // user name
	$cd_password = "sElling@348"; // password
	$cd_dbname = "companydirectory"; // database name

	/*
	$cd_host = "sql311.epizy.com";
	$cd_port = 3306;
	$cd_socket = "";
	$cd_user = "epiz_27518577"; // user name
	$cd_password = "l95yyjPYbSYlXi"; // password
	$cd_dbname = "epiz_27518577_XXX"; // database name
	*/

?>